# AIM Java Web Course

## Unit 3 Written summary

### Adam Perry

---

&nbsp;

>What things went well for you this week?

I was very glad to hear more about OOP concepts! They've never really stuck in my mind, but after the in-class examples and the homework, I think I'm starting to grasp it. It was great to see real examples about each of the four concepts.

---

&nbsp;

>What was challenging for you this week?

This week the first class was a little challenging to follow along with, as I wasn't always sure what the point of the examples were. The second class made a lot more sense though, and the homework also helped a lot.

---

&nbsp;

>How can you overcome these challenges?

I'm continuing with the Codecademy Java course but still need to catch up with it. I'm also starting to get familiarized with the online documentation sources for Java. Googling my errors is getting easier as I learn more of the syntax/terms as well.

---

&nbsp;

>What was most engaging for you this week?

I liked the in-class animal examples a lot! I was able to tweak them during the class to better understand the concepts. As always, I enjoyed the homework, especially the more challenging problems. 
