package com.aim.movie.domain;

public class Director extends Person {

}
