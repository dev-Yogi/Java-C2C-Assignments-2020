package com.aim.movie;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class App2 {
    public static final String URL = "jdbc:mysql://localhost:3306/moviedbmysql?";
    private static final String USER = "root";
    private static final String PASS = "B3xl3315";

    public static void main(String[] args) {
        try {
            // Create Scanner for user input
            Scanner input = new Scanner(System.in);
            System.out.println("Please enter a movie title:");
            // read the next line from the stream (entered from the keyboard) and store it
            // in a String variable named movieTitle
            String movieTitle = input.nextLine();
            input.close();

            // String variable set equal select statement
            String sql = "select movie_name, first_name, last_name from movies m"
                    + "join directors d on d.director_id = m.director_id where m.movie_name = '" + movieTitle + "';";

            // create string builder for better performance and readability
            // pay close attention to syntax! you will get an error if there are any
            // misplaced spaces
            StringBuilder sql2 = new StringBuilder();
            sql2.append("select movie_name, first_name, last_name ");
            sql2.append("from movies m ");
            sql2.append("join directors d on d.director_id = m.director_id ");
            sql2.append("where m.movie_name = " + "Avatar" + ";");

            System.out.println("Movie Title: " + movieTitle);

            Connection connection = DriverManager.getConnection(URL, USER, PASS);
            Statement statement = connection.createStatement();
            // querying the name of the movie
            ResultSet resultSet = statement.executeQuery(sql2.toString());

            // printing movie title from database and not user input
            while (resultSet.next()) {
                String movieName = resultSet.getString("movie_name");
                System.out.println("Movie Title: " + movieName);

                String directorsFirstName = resultSet.getString("first_name");
                String directorsLastName = resultSet.getString("last_name");
                System.out.println("Director's Name: " + directorsFirstName + " " + directorsLastName);
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
