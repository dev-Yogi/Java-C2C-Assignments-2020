package com.aim.movie.domain;

import com.aim.movie.domain.Person;

public class Actor extends Person {

}
