package com.aim.movie;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class App {
    public static final String URL = "jdbc:mysql://localhost:3306/movie1?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "B3xl3315";

    public static void main(String[] args) {
        try {

            // create scanner for user input
            Scanner input = new Scanner(System.in);
            System.out.println("Please Enter a movie title:");
            String movieTitle = input.nextLine();
            input.close();

            StringBuilder sql2 = new StringBuilder();
            sql2.append("select movie_name, first_name, last_name ");
            sql2.append("from movies m ");
            sql2.append("join directors d on d.director_id = m.director_id ");
            sql2.append("where m.movie_name = '" + movieTitle + "'';");

            System.out.println("Movie Title: " + movieTitle);

            Connection connection = DriverManager.getConnection(URL, USER, PASS);
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql2.toString());

            while (resultSet.next()) {
                String movieName = resultSet.getString("movie_name");
                System.out.println("Movie Title: " + movieName);
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
