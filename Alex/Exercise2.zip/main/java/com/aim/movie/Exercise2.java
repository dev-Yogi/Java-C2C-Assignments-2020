
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import com.aim.movie.domain.Actor;
import com.aim.movie.domain.Director;
import com.aim.movie.domain.rating;
import com.aim.movie.domain.Genre;
import com.aim.movie.domain.Movie;
import com.aim.movie.util.MySQL;

public class Exercise2 {

    public static StringBuilder sql = null;

    public static void main(String[] args) {

        try (Connection connection = DriverManager.getConnection(MySQL.URL.value, MySQL.USER.value, MySQL.PASS.value)) {

            System.out.println(
                    "This program displays the Director, Genre and Rating of movies with the name supplied by a user.");
            String movieTitle = getMovieInput();

            ResultSet movieResultSet = getMovieResultSet(connection, movieTitle);

            if (movieResultSet == null) {
                System.out.println("No Information");
                System.exit(-1);
            }

            String tableHeaders = createRow("Movie Title", "Director/Actors", "Genre", "Rating");
            String tableLines = createRow("-----------", "---------------", "-----", "------");
            System.out.print("\n" + tableHeaders + tableLines);

            List<Movie> movies = getMovieList(connection, movieResultSet);

            for (Movie movie : movies) {
                System.out.print(createRow(movie.getMovieTitle(), movie.getDirector().getFullName(), movie.getGenre(),
                        movie.getRating()));
                for (Actor actor : movie.getActors()) {
                    System.out.print(createRow("", actor.getFullName(), "", ""));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String createRow(String title, String person, String genre, String rating) {
        return String.format("%-25s%-25s%-20s%-10s%n", title, person, genre, rating);
    }

    public static String getMovieInput() {
        Scanner input = new Scanner(System.in);
        System.out.print("\nPlease enter a movie title: ");
        String movieTitle = input.nextLine();
        input.close();
        return movieTitle;
    }

    public static ResultSet getMovieResultSet(Connection connection, String movieTitle) {
        sql = new StringBuilder();
        sql.append("SELECT m.movie_name, m.movie_length, m.release_date, ");
        sql.append("d.first_name, d.last_name, r.rating, g.genre, m.movie_id ");
        sql.append("FROM movies m ");
        sql.append("JOIN directors d ON d.director_ID = m.director_id ");
        sql.append("JOIN ratings r ON r.rating_id = m.rating_id ");
        sql.append("JOIN genres g ON g.genre_id = m.genre_id ");
        sql.append("WHERE m.movie_name = ?;");

        try {
            Statement statement = connection.Statement(sql.toString());
            statement.setString(1, movieTitle);
            return statement.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("\nSQL (copy the SQL statement below and run it if you're having problems): \n"
                    + sql.toString() + "\n");
        }
        return null;
    }

    private static List<Movie> getMovieList(Connection connection, ResultSet movieResultSet) {
        List<Movie> movies = new ArrayList<Movie>();

        try {

            while (movieResultSet.next()) {
                Movie movie = new Movie();
                movie.setMovieTitle(movieResultSet.getString("movie_name"));
                movie.setMovieLength(movieResultSet.getInt("movie_length"));
                movie.setReleaseDate(movieResultSet.getDate("release_date"));
                movie.setGenre(movieResultSet.getString("genre"));
                movie.setRating(movieResultSet.getString("rating"));
                movie.setId(movieResultSet.getInt("movie_id"));

                Director director = new Director();
                director.setFirstName(movieResultSet.getString("first_name"));
                director.setLastName(movieResultSet.getString("last_name"));

                movie.setDirector(director);

                movie.setActors(getActorList(connection, movie));

                movies.add(movie);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("\nSQL (copy the SQL statement below and run it if you're having problems): \n"
                    + sql.toString() + "\n");
        }
        return movies;
    }

    private static List<Actor> getActorList(Connection connection, Movie movie) {
        ArrayList<Actor> actors = new ArrayList<Actor>();
        sql = new StringBuilder();
        sql.append("SELECT m.movie_name, a.first_name, a.last_name ");
        sql.append("FROM movies m ");
        sql.append("JOIN movies_actors ma ON ma.movie_id = m.movie_id ");
        sql.append("JOIN actors a ON a.actor_id = ma.actor_id ");
        sql.append("WHERE m.movie_id = ?;");

        try {
            Statement statement = connection.createStatement(sql.toString());
            statement.setInt(1, movie.getId());
            ResultSet actorResultSet = statement.executeQuery();

            while (actorResultSet.next()) {
                Actor actor = new Actor();
                actor.setFirstName(actorResultSet.getString("first_name"));
                actor.setLastName(actorResultSet.getString("last_name"));
                actors.add(actor);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("\nSQL (copy the SQL statement below and run it if you're having problems): \n"
                    + sql.toString() + "\n");
        }

        return actors;
    }
}
