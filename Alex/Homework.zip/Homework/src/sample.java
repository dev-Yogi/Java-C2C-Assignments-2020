
import java.util.Scanner; // import the Scanner class 

class sample {
    public static void main(String[] args) {
        Scanner temp = new Scanner(System.in);
        double result;
        int input;

        
        System.out.println("This program converts a temperature in degrees Celsius into a temperature in degrees Fahrenheit. Enter a temperature in degrees Celsius:");
        input = temp.nextInt();
        result = (9.0/5.0) * input + 32;

        System.out.println(input + " degrees Celius is equal to " + result + " degrees Farienheight");
    }
}
