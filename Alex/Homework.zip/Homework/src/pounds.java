public class pounds {
    
    public static void main(String[] args) {
        



        for (int i = 0; i < 10; i++) {
            System.out.println(i + " Kilograms is equal to " + (i * 2.2) + " pounds.");
        }
    }
}
