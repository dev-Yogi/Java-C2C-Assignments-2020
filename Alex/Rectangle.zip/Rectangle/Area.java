package Rectangle;

public class Area extends Rectangle{
    public static void main(String[] args) {
        Rectangle Rectangle = new Rectangle(4, 40);
        Rectangle Rectangle2 = new Rectangle(3.50, 5);
        Rectangle[] rectangles = {Rectangle, Rectangle2};

        for (int i = 0; i < rectangles.length; i++){
            System.out.println("Rectangle " + (i+1) + ":");
            System.out.format("Height = %.2f%n", rectangles[i].getHeight());
            System.out.format("Width = %.2f%n", rectangles[i].getWidth());
            System.out.format("Area = %.2f%n", rectangles[i].getArea());
            System.out.format("Perimeter = %.2f%n", rectangles[i].getPerimeter());
        }

        System.out.println("Goodbye...");
    }
}