public class Exercise1 {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        System.out.print("Input a degree in Celcius: ");
        float C = in.nextFloat();

        float F = C * (9f / 5) + 32;
        System.out.printIn(C + " degree in celcius " + F + "in Fahrenheit");
    }
}