package com.aim.AimUnit5Movie.Movie.movie;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="movies")
public class Movie {
    private int movieId;
    private int directorId;
    private int ratingId;
    private int genreId;
    private String movieName;
    private int movieLength;

    public Movie(){

    }

    public Movie(int movieId, int directorId, int ratingId, int genreId, String movieName, int movieLength) {
        this.movieId = movieId;
        this.directorId = directorId;
        this.ratingId = ratingId;
        this.genreId = genreId;
        this.movieName = movieName;
        this.movieLength = movieLength;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public int getDirectorId() {
		return directorId;
	}

	public void setDirectorId(int directorId) {
		this.directorId = directorId;
	}

	public int getRatingId() {
		return ratingId;
	}

	public void setRatingId(int ratingId) {
		this.ratingId = ratingId;
	}

	public int getGenreId() {
		return genreId;
	}

	public void setGenreId(int genreId) {
		this.genreId = genreId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public int getMovieLength() {
		return movieLength;
	}

	public void setMovieLength(int movieLength) {
		this.movieLength = movieLength;
	}

 }