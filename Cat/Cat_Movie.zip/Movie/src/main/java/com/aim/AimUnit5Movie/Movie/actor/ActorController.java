package com.aim.AimUnit5Movie.Movie.actor;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/api/actors")
public class ActorController {
    @Autowired
    private ActorRepository actorRepository;

    @GetMapping("")
    public @ResponseBody Iterable<Actor>getAllActors(){
        return actorRepository.findAll();
    }
    @GetMapping("/{id}")
    public @ResponseBody Actor getActor(@PathVariable(value="id") Integer id){
        Optional<Actor> actor = actorRepository.findById(id);
        return actor.get();
    }

    @PostMapping("/")
    public @ResponseBody String addActor(@RequestBody Actor actor) {
        actorRepository.save(actor);
        return "Saved";
    }

    @PutMapping("/{id}")
    public @ResponseBody String updateActor(@PathVariable(value="id") Integer id, @RequestBody Actor actorDetails){
    actorRepository.save(actorDetails);
    return "Updated";
    }

    @DeleteMapping("/{id}")
    public @ResponseBody String deleteActor(@PathVariable(value="id") Integer id, @RequestBody Actor deleteActor) {
        actorRepository.delete(deleteActor);
        return "Deleted";
    }
    
}
