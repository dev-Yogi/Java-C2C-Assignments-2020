package com.aim.AimUnit5Movie.Movie.directors;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/api/directors")
public class DirectorsController {
    @Autowired
    private DirectorsRepository directorsRepository;

    @GetMapping("")
    public @ResponseBody
    Iterable<Directors>getAllDirectors() {
        return directorsRepository.findAll();
    }
    @GetMapping("/{id}")
    public@ResponseBody Directors getDirectors (@PathVariable(value="id") Integer id) {
        Optional<Directors> directors = directorsRepository.findById(id);
        return directors.get();
    }

    @PostMapping("/")
    public @ResponseBody String addDirectors(@RequestBody Directors directors) {
        directorsRepository.save(directors);
        return "Saved";
    }
     @PutMapping("/{id}")
     public @ResponseBody String updateDirectors(@PathVariable(value="id") Integer id, @RequestBody Directors directorsDetails) {
         directorsRepository.save(directorsDetails);
         return "Updated";
     }

     @DeleteMapping("/{id}")
     public @ResponseBody String deleteDirectors(@PathVariable(value="id") Integer id, @RequestBody Directors deleteDirectors) {
         directorsRepository.delete(deleteDirectors);
         return "Deleted";
     }
}
