package com.aim.AimUnit5Movie.Movie.actor;

import org.springframework.data.repository.CrudRepository;

public interface ActorRepository extends CrudRepository<Actor, Integer>{

} 
    

