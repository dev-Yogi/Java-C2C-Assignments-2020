package com.aim.AimUnit5Movie.Movie.directors;

import org.springframework.data.repository.CrudRepository;

public interface DirectorsRepository extends CrudRepository<Directors, Integer>{
    
}
