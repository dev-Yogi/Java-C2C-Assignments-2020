package com.aim.AimUnit5Movie.Movie.movie;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/movies")
public class MovieController {
    @Autowired
    private MovieRepository movieRepository;

    @GetMapping("") 
        public Iterable<Movie> getAllMovies(){
            return movieRepository.findAll();
        }
    @GetMapping("/{id}")
    public Movie getMovie(@PathVariable(value="id") Integer id) {
        Optional<Movie>movie = movieRepository.findById(id);
        return movie.get();
    }

    @PostMapping("/")
    public Movie createMovie(@RequestBody Movie movie) {
        return movieRepository.save(movie);
    }

    @PutMapping("/{id}")
    public @ResponseBody String updateMovie(@PathVariable(value="id") Integer id, @RequestBody Movie movieDetails) {
        movieRepository.save(movieDetails);
        return "Updated";
    }
    
    @DeleteMapping("/{id}")
    public @ResponseBody String deleteMovie (@PathVariable(value="id") Integer id, @RequestBody Movie deleteMovie) {
        movieRepository.delete(deleteMovie);
        return "Deleted";
    }
}
