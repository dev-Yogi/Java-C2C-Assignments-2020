package com.aim.Java.movie.MovieDB.rating;

import org.springframework.data.repository.CrudRepository;

public interface RatingRepository extends CrudRepository<Rating, Integer>{
    
}
