package com.aim.Java.movie.MovieDB.director;

import org.springframework.data.repository.CrudRepository;

public interface DirectorRepository extends CrudRepository<Director, Integer> {
    
}
