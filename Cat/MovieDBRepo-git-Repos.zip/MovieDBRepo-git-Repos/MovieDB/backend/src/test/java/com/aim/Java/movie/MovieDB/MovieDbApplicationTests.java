package com.aim.Java.movie.MovieDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
