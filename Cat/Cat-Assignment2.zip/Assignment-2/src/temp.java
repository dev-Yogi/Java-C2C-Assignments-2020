import java.util.Scanner; //import the Scanner class 

public class temp {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("This programe converts a temperature in degress Celsius into a temperature in degress Fahrenheit.");
        System.out.print("Enter temperature in degrees Celcius: "); 
        double C = in.nextDouble();

        double F = C * (9.0 / 5.0) + 32;

        System.out.println(C + " degree Celsius is equal to " + F + " degree Fahrenheit.");

        System.out.println("Goodbye...");

    }    
}
