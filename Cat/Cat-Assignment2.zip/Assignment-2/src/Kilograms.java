public class Kilograms {
    public static void main(String[] args) {
     double pounds = 2.2;
     System.out.println("This program converts kilograms to pounds.");
     System.out.println("kilograms        pounds");
     System.out.println("---------        ------");

     for (int i = 1; i <=15; i = i + 2) {
         System.out.format(i + "                " + "%5.2f%n", (i * pounds));
     }
       System.out.println("Goodbye...");
   }
 
}