import java.util.Scanner; //import the Scanner class 

public class Days {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int daysInMonth = 0;
        String MonthName = "Unknown";
        
        System.out.println("Given a year and a month in that year, this program will tell you the number of days in that month.");

        System.out.print("Input a year: ");
        int year = input.nextInt();

        System.out.print("Enter a value for the month (1 = Jan, 2 = Feb, etc): ");
        int month = input.nextInt();      

        switch (month) {
            case 1:
                MonthName = "January";
                daysInMonth = 31;
                break;
            case 2:
                MonthName = "February";
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    daysInMonth = 29;
                } else {
                    daysInMonth = 28;
                }
                break;
            case 3:
                MonthName = "March";
                daysInMonth = 31;
                break;
            case 4: 
                MonthName = "April";
                daysInMonth = 30;
                break;
            case 5:
                MonthName = "May";
                daysInMonth = 31;
                break;
            case 6:
                MonthName = "June";
                daysInMonth = 30;
                break;
            case 7: 
                MonthName = "July";
                daysInMonth = 31;
                break;
            case 8: 
                MonthName = "August";
                daysInMonth = 31;
            case 9: 
                MonthName = "September";
                daysInMonth = 30;
                break;
            case 10:
                MonthName = "Ocotber";
                daysInMonth = 31;
                break;
            case 11:
                MonthName = "November";
                daysInMonth = 30;
                break;
            case 12:
                MonthName = "December";
                daysInMonth = 31;
                break;
                          
        }
        if (month > 12) {
            System.out.println(month + " is invalid. Month values must be between 1 and 12, inclusive.");
        }else {
            System.out.println(MonthName + " " + year + " has " + daysInMonth + " days. ");
        }       
        
        System.out.println("Goodbye...");
    }
}
