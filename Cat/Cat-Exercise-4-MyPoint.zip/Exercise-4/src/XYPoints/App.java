package XYPoints;

import java.util.Scanner;

public class App {
    public static void main(final String[] args) {
        final Scanner scanner = new Scanner(System.in);

    System.out.println("\nThis program creates a point at (0,0) and a point at the coordinates\nentered by you. It then computes and displays the distance from (0,0)\nto the point defined by you, using three different methods.\n");   
      int x,y;
        final MyPoint p1 = new MyPoint();
        System.out.print("Enter the x coordinate of a point: ");
        x = scanner.nextInt();
        System.out.print("Enter the y coordinate of a point: ");
        y=scanner.nextInt();

        System.out.format("\nUsing Method 1, the distance between " + p1 + " to ("+ x +","+ y +") is " + "%.2f%n", (p1.distance(x,y)));
       final MyPoint p2=new MyPoint(x, y);
      
       System.out.format("Using Method 2, the distance between " + p1 + " to ("+ x +","+ y +") is " + "%.2f%n" , (p1.distance(p2)));
      
       System.out.format("Using Method 3, the distance between " + p1 + " to ("+ x +","+ y +") is " + "%.2f%n" , (MyPoint.distance(p1,p2)));
      
       System.out.println("\nGoodbye...\n");
    }
}
