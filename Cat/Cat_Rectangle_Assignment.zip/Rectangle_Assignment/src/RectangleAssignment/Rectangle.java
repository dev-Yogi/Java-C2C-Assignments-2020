package RectangleAssignment;

public abstract class Rectangle {
    public double width;
    public double height;
    public double area;
    public double parameter;
    
    public void width() {
        System.out.println("width = " + width);
    }
    public void height() {
        System.out.println("height = " + height);
    }
    public void area() {
        System.out.println("area = " + area);
    }
    public void parameter() {
        System.out.println("parameter = " + parameter);
    }

}