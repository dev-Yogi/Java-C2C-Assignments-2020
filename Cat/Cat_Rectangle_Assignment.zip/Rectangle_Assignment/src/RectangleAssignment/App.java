package RectangleAssignment;

public class App {
    public static void main(String[] args) {
        System.out.println("\nThis program creates two rectangle objects and displays their width, height, \narea and parameter");

        System.out.println("\nRectangle 1:");
        Rectangle rectangle1 = new Rectangle1();
        rectangle1.height();
        rectangle1.width();
        rectangle1.area();
        rectangle1.parameter();
     
        System.out.println("\nRectangle 2:");
        Rectangle rectangle2 = new Rectangle2();
        rectangle2.height();
        rectangle2.width();
        rectangle2.area();
        rectangle2.parameter();

        System.out.println("\nGoodbye...\n");
    }
    
}
