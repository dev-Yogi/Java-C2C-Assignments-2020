package com.aim.java.Unit5MasterFile.moviePart2.movie;

import org.springframework.data.repository.CrudRepository;

public interface MovieRepository extends CrudRepository<Movie, Integer> {
    
}