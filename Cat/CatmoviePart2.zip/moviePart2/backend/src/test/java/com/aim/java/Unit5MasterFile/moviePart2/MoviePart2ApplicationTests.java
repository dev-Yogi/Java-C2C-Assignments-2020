package com.aim.java.Unit5MasterFile.moviePart2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviePart2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
