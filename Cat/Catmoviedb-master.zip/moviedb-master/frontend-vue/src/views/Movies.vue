<template>
  <div class="main">
    <div class="header">
    <h1 class="title">Movies</h1>
  </div>

  
  <div class="content">
      <table id="movies" class="table">
        <thead>
          <tr>
            <th>#</th>
            <th>Movie Name</th>
            <th>Movie Length</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="movie in movies" :key="movie.id">
            <td>{{movie.id}}</td>
            <td>{{director.id}}</td>
            <td>{{rating.id}}</td>
            <td>{{genre.id}}</td>
            <td>{{movie.movieName}}</td>
            <td>{{movie.movieLength}}</td>
          </tr>
        </tbody>
      </table>
  </div> 
  
  </div>
</template>

<script>
export default {
  name: 'Movies',
  data: () => ({
    movies:[]
  }),
  async mounted() {
    console.log('movies mounted being')
    const {data} = await this.$http.get('http://localhost:8080/api/movies');
    console.log('movies mounted data', data)
    this.movies = data;
  }
}
</script>


