package com.aim.java.Unit5MovieMaster.moviedb.movie;

import org.springframework.data.repository.CrudRepository;

public interface MovieRepository extends CrudRepository<Movie, Integer> {
    
}
