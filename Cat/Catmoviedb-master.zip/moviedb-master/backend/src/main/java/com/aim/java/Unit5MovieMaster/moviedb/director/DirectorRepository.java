package com.aim.java.Unit5MovieMaster.moviedb.director;

import org.springframework.data.repository.CrudRepository;

public interface DirectorRepository extends CrudRepository<Director, Integer>{
    
}
