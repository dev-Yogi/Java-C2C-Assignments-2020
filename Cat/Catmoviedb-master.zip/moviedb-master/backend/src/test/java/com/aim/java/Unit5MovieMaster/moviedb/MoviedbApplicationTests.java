package com.aim.java.Unit5MovieMaster.moviedb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviedbApplicationTests {

	@Test
	void contextLoads() {
	}

}
