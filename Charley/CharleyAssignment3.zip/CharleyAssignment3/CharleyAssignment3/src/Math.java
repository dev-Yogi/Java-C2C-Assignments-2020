public class Math{
    public class Rectangle extends App {
        double height;
        double width;
    }

    Rectangle(double height, double width) {
        this.height = height;
        this.width = width;
     }

    double getHeight() {
        return height;
    }

    double setHeight() {

    }

    double getWidth() {
        return width;
    }

    double getArea() {
         return height * width;
     }

     double getPerimeter() {
         return 2 * (height + width);
     }

 Rectangle rectangle1 = new Rectangle();
 Rectangle rectangle2 = new Rectangle();

    }
