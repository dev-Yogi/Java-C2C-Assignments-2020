public abstract class App{

public static void main(String[] args){

        System.out.println("This program creates two rectangle objects and displays their width, height, area and perimeter. ");
        System.out.println("Rectangle 1: \n height = " + rectangle1.getHeight());
        System.out.println("width = " + rectangle1.getWidth());
        System.out.println("area = " + rectangle1.getArea());
        System.out.println("perimeter = " + rectangle1.getPerimeter());
        System.out.println("Rectangle 2: \n height = " + rectangle2.getHeight());
        System.out.println("width = " + rectangle2.getWidth());
        System.out.println("area = " + rectangle2.getArea());
        System.out.println("perimeter = " + rectangle2.getPerimeter());
        System.out.println("GoodBye...");

    }

 }