package com.aim.java.Unit5Movie.movie.entity.actor;

import org.springframework.data.repository.CrudRepository;

public interface ActorRepository extends CrudRepository<Actor, Integer> {

}
