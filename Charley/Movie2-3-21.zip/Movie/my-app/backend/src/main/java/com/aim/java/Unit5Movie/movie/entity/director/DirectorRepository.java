package com.aim.java.Unit5Movie.movie.entity.director;

import org.springframework.data.repository.CrudRepository;

public interface DirectorRepository extends CrudRepository<Director, Integer> {
    
}
