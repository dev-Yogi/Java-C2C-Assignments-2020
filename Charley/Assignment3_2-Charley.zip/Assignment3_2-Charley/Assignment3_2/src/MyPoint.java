public class MyPoint {
    private int x;
    private int y;

    public MyPoint(){
        setX(0);
        setY(0);
    }

    public MyPoint (int xCoord, int yCoord){
        setX(xCoord);
        setY(yCoord);
    }

    public static double distance(MyPoint mp1, MyPoint mp2) {
        double xDifference = Math.pow(mp1.getX() - mp2.getX(), 2);
        double yDifference = Math.pow(mp1.getY() - mp2.getY(), 2);
        return Math.sqrt(xDifference + yDifference);
    }

    public double distance(int xCoord, int yCoord){
        double xDifference = Math.pow(xCoord - getX(), 2);
        double yDifference = Math.pow(yCoord - getY(), 2);
        return Math.sqrt(xDifference + yDifference);
    }

    public double distance(MyPoint p){
        double xDifference = Math.pow(p.getX() - getX(), 2);
        double yDifference = Math.pow(p.getY() - getY(), 2);
        return Math.sqrt(xDifference + yDifference);
    }

  

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }



}