import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        System.out.println(
            "This program creates a point at (0,0) and a point at the coordinates entered by you.\n" +
            "It then computes and displays the distance from (0,0) \n" +
             "to the point defined by you, using three different methods"
        );

        MyPoint point1 = new MyPoint(0,0);

        Scanner coords = new Scanner(System.in);

        System.out.println("Enter the x coordinate of a point: ");
        int xCoord = coords.nextInt();
        System.out.println("Enter the Y coordinte of a point: ");
        int yCoord = coords.nextInt();
        MyPoint userPoint = new MyPoint(xCoord, yCoord);

        double method1 = point1.distance(userPoint.getX(), userPoint.getY());
        double method2 = point1.distance(userPoint);
        double method3 = MyPoint.distance(point1, userPoint);


        System.out.println("Using method 1, the distance from " + point1 + " to " + userPoint + " is " + method1);
        System.out.println("Using method 2, the distance from " + point1 + " to " + userPoint + " is " + method2);
        System.out.println("Using method 3, the distance from " + point1 + " to " + userPoint + " is " + method3);

    }

}
