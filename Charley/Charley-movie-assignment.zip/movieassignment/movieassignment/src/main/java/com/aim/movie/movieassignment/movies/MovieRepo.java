package com.aim.movie.movieassignment.movies;

import org.springframework.data.repository.CrudRepository;

public interface MovieRepo extends CrudRepository<Movie, Integer> {

}
