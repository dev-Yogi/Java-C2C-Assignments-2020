package com.aim.movie.movieassignment.directors;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/directors")

public class DirectorController {
    @Autowired
    private DirectorRepo directorRepo;

    @GetMapping("")
    public Iterable<Director> getAllDirectors() {
        return directorRepo.findAll();
    }

    @GetMapping("/{id}")
    public Director get(@PathVariable Integer id) {
        Optional<Director> director = directorRepo.findById(id);
        return director.get();
    }

    @PostMapping("/")
    public void add(@RequestBody Director director) {
        directorRepo.save(director);
    }

    @PutMapping("/{id}")
    public void update(@RequestBody Director director, @PathVariable Integer id) {
        director.setDirector_id(id);
        directorRepo.save(director);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        directorRepo.deleteById(id);
    }
    
}
