package com.aim.movie.movieassignment.actors;

import org.springframework.data.repository.CrudRepository;

public interface ActorRepo extends CrudRepository<Actor, Integer>{
    
}
