package com.aim.movie.movieassignment.movies;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/movies")

public class MovieController {

    @Autowired
    private MovieRepo movieRepo;

    @GetMapping("")
    public Iterable<Movie> getAllMovies() {
        return movieRepo.findAll();
    }

    @GetMapping("/{id}")
    public Movie get(@PathVariable Integer id) {
        Optional<Movie> movie = movieRepo.findById(id);
        return movie.get();
    }

    @PostMapping("/")
    public void add(@RequestBody Movie movie) {
        movieRepo.save(movie);
    }

    @PutMapping("/{id}")
    public void update(@RequestBody Movie movie, @PathVariable Integer id) {
        movie.setId(id);
        movieRepo.save(movie);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        movieRepo.deleteById(id);
    }

}
