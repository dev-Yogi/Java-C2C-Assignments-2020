package com.aim.movie.movieassignment.directors;

import org.springframework.data.repository.CrudRepository;

public interface DirectorRepo extends CrudRepository<Director, Integer> {

}
