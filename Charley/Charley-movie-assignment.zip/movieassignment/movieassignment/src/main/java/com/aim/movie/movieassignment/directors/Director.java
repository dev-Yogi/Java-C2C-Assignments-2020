package com.aim.movie.movieassignment.directors;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "directors")

public class Director {
     private int director_id;
    private String first_name;
    private String last_name;
    
    public Director() {

    }

    public Director(int id, String firstName, String lastName) {
        this.director_id = id;
        this.first_name = firstName;
        this.last_name = lastName;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

	public int getDirector_id() {
		return director_id;
	}

	public void setDirector_id(int director_id) {
		this.director_id = director_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
}
