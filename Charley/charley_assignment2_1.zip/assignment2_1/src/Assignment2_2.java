import java.util.Scanner;

public class Assignment2_2 {
    public static void main(String[] args) {

        System.out.println("Given a year and a month in that year, this program will tell you the number of days in that month.");

        Scanner userInput = new Scanner(System.in);

        int numOfDays = 0;
        String nameOfMonth = "Changeable";

        System.out.println( "Enter a year: ");
        int year = userInput.nextInt();
        System.out.println("Enter a value for the month (1 = Jan, 2 = Feb, etc): ");
        int month = userInput.nextInt();


        switch (month){
            case 1:
                nameOfMonth = "January";
                numOfDays = 31;
                break;
            case 2:
                nameOfMonth = "February";
                    if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0){
                        numOfDays= 29;
                    } else {
                        numOfDays = 28;
                    }
                break;
            case 3: 
                    nameOfMonth = "March";
                    numOfDays = 31;
                break;
            case 4:
                    nameOfMonth = "April";
                    numOfDays = 30;
                break;
            case 5 :
                    nameOfMonth = "May";
                    numOfDays = 31;
                break;
            case 6: nameOfMonth = "June";
                    numOfDays = 30;
                break;
            case 7:
                    nameOfMonth ="July";
                    numOfDays = 31;
                break;
            case 8:
                    nameOfMonth = "August";
                    numOfDays = 31;
                break;
            case 9:
                    nameOfMonth = "Septermber";
                    numOfDays = 30;
                break;
            case 10: nameOfMonth = "October";
                    numOfDays = 31;
                break;
            case 11: 
                    nameOfMonth = "November";
                    numOfDays = 30;
                break;
            case 12:
                    nameOfMonth ="December";
                    numOfDays= 31;
                break;
                default: 
                System.out.println(month + " is invalid. Month values must be between 1 and 12, inclusive.");
        }
        System.out.println(nameOfMonth + "of " + year + " has " + numOfDays + " days in it.");
        System.out.println("Goodbye ...");
                
    }
}