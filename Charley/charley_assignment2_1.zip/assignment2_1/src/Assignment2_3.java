public class Assignment2_3 {
    public static void main(String[] args) {
        System.out.println("Kilograms   Pounds");
        System.out.println("---------   ------");
        for (int i = 1; i < 15; i = i+2){
            System.out.println( i + "           " + i * 2.2);
           
        }
        System.out.println("Goodbye...");
    }
}