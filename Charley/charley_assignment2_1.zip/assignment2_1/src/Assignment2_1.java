import java.util.Scanner;

public class Assignment2_1{

    public static void main(String[] args) {

        Scanner userInput = new Scanner(System.in);

        System.out.print("This program converts a temperature in degrees Celsius into a temperature in degrees Fahrenheit. Enter a temperature in degrees Celsius: ");

        int celsius = userInput.nextInt();
        double fahrenheit = (9.0/5.0) * celsius + 32;

        System.out.println(celsius + " degrees Celsius is equal to " + fahrenheit + " degrees Fahrenheit");
        System.out.println("Goodbye ...");

    }
}