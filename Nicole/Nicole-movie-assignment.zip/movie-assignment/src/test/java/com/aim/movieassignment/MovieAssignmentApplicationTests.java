package com.aim.movieassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
