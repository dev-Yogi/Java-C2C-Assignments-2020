package com.aim.movieassignment.movies;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "movies")

public class Movie {
    private int id;
    private String movieName;

    public Movie() {

    }

    public Movie(int id, String movieName) {
        this.id = id;
        this.movieName = movieName;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    //Getters and Setters
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
    
}
