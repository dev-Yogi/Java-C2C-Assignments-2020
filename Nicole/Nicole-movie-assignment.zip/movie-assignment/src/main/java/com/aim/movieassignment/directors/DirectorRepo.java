package com.aim.movieassignment.directors;

import org.springframework.data.repository.CrudRepository;

public interface DirectorRepo extends CrudRepository<Director, Integer> {
    
}
