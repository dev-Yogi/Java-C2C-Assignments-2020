package com.aim.movieassignment.actors;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/actors")

public class ActorController {
    @Autowired
    private ActorRepo actorRepo;

    @GetMapping(path = "")
    public Iterable<Actor> getAllActors() {
        return actorRepo.findAll();
    }

    @GetMapping("/{id}") 
    public Actor get(@PathVariable Integer id) {
            Optional<Actor> actor = actorRepo.findById(id);
            return actor.get();
    }

    @PostMapping("/")
    public void add(@RequestBody Actor actor) {
        actorRepo.save(actor);
    }

    @PutMapping("/{id}")
    public void update(@RequestBody Actor actor, @PathVariable Integer id) {
            actor.setId(id);
            actorRepo.save(actor);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        actorRepo.deleteById(id);
    }


}
