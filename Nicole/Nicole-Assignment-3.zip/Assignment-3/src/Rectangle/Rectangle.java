package Rectangle;

public class Rectangle {
    double height = 1;
    double width = 1;
    String rectangle;
    
    
    public Rectangle() {
        this.rectangle = "Default Rectangle";
    }

    public Rectangle(String rectangle, double height, double width) {
        this.rectangle = rectangle;
        this.height = height;
        this.width = width;
    }

    public void getRectangle() {
        System.out.println("\n\n" + rectangle + ":");
    }

    public void setRectangle(String rectangle) {
        this.rectangle = rectangle;
    }

    public void getHeight() {
        System.out.format("height = %.2f", height);
    }

    public void getWidth() {
        System.out.format("\nwidth = %.2f", width);
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public void getArea(double height, double width) {
        double area = height * width;
        System.out.format("\narea = %.2f", area);
    }

    public void getPerimeter(double height, double width) {
        double perimeter = 2 * (height + width);
        System.out.format("\nperimeter = %.2f", perimeter);
    }

}