package Rectangle;

public class App {

    public static void main(String[] args) {
        Rectangle r1 = new Rectangle("Rectangle 1", 4, 40);
        Rectangle r2 = new Rectangle("Rectangle 2", 3.5, 5);
        
        System.out.print("This program creates two rectangles and displays their width, height, \narea and perimeter.");

        r1.getRectangle();
        r1.getHeight();
        r1.getWidth();
        r1.getArea(r1.height, r1.width);
        r1.getPerimeter(r1.height, r1.width);

        r2.getRectangle();
        r2.getHeight();
        r2.getWidth();
        r2.getArea(r2.height, r2.width);
        r2.getPerimeter(r2.height, r2.width);
        
        System.out.println("\n\nGoodbye...");
    }
}
