import java.util.Scanner;

public class Temperature {
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        double tempC;
        double tempF;

        System.out.println("This program converts a temperature in degrees Celsius into a temperature in degrees Farenheit.");
        System.out.print("Enter a temperature in degrees Celsius: ");
        tempC = input.nextDouble();
        input.close();

        tempF = (9.0/5.0) * tempC + 32;

        System.out.format("\n%.2f degrees Celsius is equal to %.2f degrees Fahrenheit.", tempC, tempF);
        System.out.println("\n \nGoodbye...");

    }
}