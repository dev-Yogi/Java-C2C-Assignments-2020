import java.util.Scanner;

public class DaysInMonth {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        int year;
        int monthNumber;
        String month = null;

        System.out.println("Given a year and a month in that year, this program will tell you the number of days in that month. \n");
        System.out.print("Enter a year: ");
        year = input.nextInt();

        System.out.print("\nEnter a value for the month(1 = Jan, 2 = Feb, etc): ");
        monthNumber = input.nextInt();
        input.close();

        if(monthNumber < 1 || monthNumber > 12){
            System.out.println(monthNumber + " is invalid. Month values must be between 1 and 12, inclusive. \n Goodbye...");
        }
        else{
            switch(monthNumber) {
                case 1:
                    month = "January";
                    break;

                case 2:
                    month = "February";
                    break;

                case 3:
                    month = "March";
                    break;

                case 4:
                    month = "April";
                    break;

                case 5:
                    month = "May";
                    break;

                case 6:
                    month = "June";
                    break;

                case 7:
                    month = "July";
                    break;

                case 8:
                    month = "August";
                    break;

                case 9:
                    month = "September";
                    break;

                case 10:
                    month = "October";
                    break;

                case 11:
                    month = "November";
                    break;

                case 12:
                    month = "December";
                    break;
            }
        }

        if(year % 4 == 0 && year % 100 != 0 || year % 400 == 0 && monthNumber == 2){
            System.out.println(month + " of " + year + " has 29 days in that month. \nGoodbye...");
        }
        else if(monthNumber == 2) {
            System.out.println(month + " of " + year + " has 28 days in that month. \nGoodbye...");
        }
        else if(monthNumber == 4 || monthNumber == 6 || monthNumber == 9 || monthNumber == 11){
            System.out.println(month + " of " + year + " has 30 days in that month. \nGoodbye...");
        }
        else{
            System.out.println(month + " of " + year + " has 31 days in that month. \nGoodbye...");
        }

    }
    
}
