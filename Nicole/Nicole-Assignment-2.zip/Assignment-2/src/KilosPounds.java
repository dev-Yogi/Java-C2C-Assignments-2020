public class KilosPounds {
    public static void main(String[] args) {
        int kilo = 1;
        double pounds;

        System.out.println("This program will show a table converting kilograms to pounds. \nIt will show odd numbers from 1 to 15 in kilos. \n\n\n");

        System.out.println("kilograms     pounds");
        System.out.println("---------     ------");
        while(kilo <= 15) {
            pounds = kilo * 2.2;
            if(kilo < 10){
                System.out.format(kilo + "             %.1f", pounds);
            }
            else{
                System.out.format(kilo + "            %.1f", pounds);
            }
            System.out.println();
            kilo = kilo + 2;
        }

        System.out.println("\nGoodbye...");

    }
    
}
