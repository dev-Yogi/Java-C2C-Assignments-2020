SELECT * FROM [Customers]
SELECT * FROM [Employees]
SELECT * FROM [Orders]
SELECT CustomerName, City FROM [Customers]

SELECT * FROM [Customers]
ORDER BY Country;

SELECT * FROM [Customers]
ORDER BY Country DESC;

SELECT * FROM [Customers]
ORDER BY Country, CustomerName;

SELECT * FROM [Customers]
ORDER BY Country ASC, CustomerName ASC;

SELECT * FROM [Customers]
ORDER BY Country ASC, CustomerName DESC;

SELECT Country FROM [Customers]
SELECT DISTINCT Country FROM [Customers]
SELECT DISTINCT City, Country FROM [Customers]

UPDATE [Customers] SET City = NULL WHERE CustomerID = 1;

SELECT * FROM [Customers] WHERE City IS NULL;

SELECT * FROM [Customers]
WHERE Country = 'Germany' AND City = 'Berlin';

SELECT * FROM [Customers]
WHERE City = 'Berlin' OR City = 'London';

SELECT * FROM [Customers]
WHERE Country = 'Germany' OR Country = 'Spain';

SELECT * FROM [Customers]
WHERE NOT Country = 'Germany';

SELECT * FROM [Customers]
WHERE Country IN ('Germany', 'France', 'UK');

SELECT * FROM [Customers]
WHERE Country IN ('Germany', 'France', 'UK');

SELECT * FROM [Customers]
WHERE Country IN (SELECT Country FROM Suppliers);

SELECT * FROM [Products]
WHERE Price BETWEEN 10 AND 20;

SELECT * FROM [Products]
WHERE Price BETWEEN 10 AND 20;

SELECT * FROM [Products]
WHERE Price BETWEEN 10 AND 20;

SELECT * FROM [Products]
WHERE Price BETWEEN 10 AND 20
AND CategoryID NOT IN (1,2,3);

SELECT * FROM [Products]
WHERE ProductName BETWEEN 'Carnarvon Tigers' AND 'Mozzarella di Giovanni'
ORDER BY ProductName;

SELECT * FROM [Customers]
WHERE CustomerName LIKE 'a%';

SELECT * FROM [Customers]
WHERE CustomerName LIKE '%a';

SELECT * FROM [Customers]
WHERE CustomerName LIKE '%or%';

SELECT * FROM [Customers]
WHERE CustomerName LIKE '_r%';

SELECT * FROM [Customers]
WHERE CustomerName LIKE 'a__%';

SELECT * FROM [Customers]
WHERE ContactName LIKE 'a%o';

SELECT * FROM [Customers]
WHERE CustomerName NOT LIKE 'a%';

SELECT * FROM [Customers] WHERE City IS NULL

SELECT COUNT(CustomerID), Country
FROM [Customers]
GROUP BY Country;

SELECT COUNT(CustomerID), Country
FROM [Customers]
GROUP BY Country
ORDER BY COUNT(CustomerID) DESC;

SELECT COUNT(CustomerID), Country
FROM [Customers]
GROUP BY Country
HAVING COUNT(CustomerID) > 5;

SELECT COUNT(CustomerID), Country
FROM [Customers]
GROUP BY Country
HAVING COUNT(CustomerID) > 5
ORDER BY COUNT(CustomerID) DESC;

SELECT COUNT(ProductID)
FROM [Products];

SELECT COUNT(ALL(Quantity)) FROM [OrderDetails]


SELECT COUNT(DISTINCT(Quantity)) FROM [OrderDetails]

SELECT AVG(Price) FROM [Products]
SELECT AVG(ALL(Price)) FROM [Products]
SELECT AVG(DISTINCT(Price)) FROM [Products]

SELECT SUM(Quantity)
FROM [OrderDetails];

SELECT MAX(Price) AS LargestPrice
FROM [Products];

SELECT ?,?, MIN(Price) AS SmallestPrice
FROM [Products];

SELECT * FROM [Customers]
WHERE City LIKE 'ber%';

SELECT * FROM [Customers]
WHERE City LIKE 'ber%';

SELECT * FROM [Customers]
WHERE City LIKE '%es%';

SELECT * FROM [Customers]
WHERE City LIKE '_ondon';

SELECT * FROM [Customers]
WHERE City LIKE 'L_n_on';




