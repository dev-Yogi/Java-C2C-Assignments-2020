public class Assignment1_1 {
    public static void main(String[] arg){
        String name = "Nicole Perry";
        String courseName = "Java Web";
        String hometown = "Omaha, NE";
        String favoriteDessert = "Tiramisu";

        System.out.println(name);
        System.out.println(courseName);
        System.out.println(hometown);
        System.out.println(favoriteDessert);
    }
}