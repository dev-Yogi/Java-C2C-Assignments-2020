package com.aim.animals;

public interface Edible {
    public abstract void howToEat();
}