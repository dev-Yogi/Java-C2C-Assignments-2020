package com.aim.animals;

public class Duck implements Pet {

    @Override
    public void play() {
        System.out.println("Pet the duck.");
    }

    @Override
    public String howToPlay() {
        // TODO Auto-generated method stub
        return null;
    }

}