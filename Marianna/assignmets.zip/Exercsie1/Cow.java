package com.aim.animals;

public class Cow implements Edible {

    @Override
    public void howToEat() {
        System.out.println("Steaks, any kind.");
    }

}