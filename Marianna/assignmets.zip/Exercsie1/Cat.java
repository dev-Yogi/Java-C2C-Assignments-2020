package com.aim.animals;

public class Cat extends Animal {

    @Override
    public void makeNoise() {
        System.out.println("Meow");
    }

    @Override
    public String howToPlay() {
        // TODO Auto-generated method stub
        return null;
    }

}