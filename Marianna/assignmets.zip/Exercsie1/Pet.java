package com.aim.animals;

public interface Pet {
    abstract void play();

    abstract String howToPlay();
}